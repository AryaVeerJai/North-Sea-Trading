const mongoose = require('mongoose');



const tokenSchema = new mongoose.Schema({
    accessToken: {
        type: String,
        required: true
    },
}, { collection: 'accesstokens' })

const Accesstoken = mongoose.model('ACCESSTOKEN', tokenSchema);

module.exports = Accesstoken;