const mongoose = require('mongoose');
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const keysecret = "northseatradingbackend";
// const validator = require("validator");


const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    company: {
        type: String,
        required: true
    },
    position: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: Number,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    tokens:[
        {
            token:{
                type: String,
                required: true
            }
        }
    ]
}, { collection: 'users' })



// Password Hashing
userSchema.pre("save", async function(next){
    if (this.isModified("password")){
        this.password = await bcrypt.hash(this.password,12);
    }

    next()
})

// token generate
userSchema.methods.generateAuthtoken = async function(){
    try {
        let _token = jwt.sign({_id:this._id},keysecret,{
            expiresIn: "1d"
        });

        this.tokens = this.tokens.concat({token:_token});
        await this.save();
        return _token;
    } catch (error) {
        res.status(422).json(error)
    }
}

// secure the password with the bcrypt
// userSchema.pre("save", async function(next){
//     const user = this;
//     if (!user.isModified("password")) {
//         next();
//     }
//     try {
//         const saltRound = await bcrypt.genSalt(10);
//         const hash_password = await bcrypt.hash(user.password, saltRound);
//         user.password = hash_password;
//     } catch (error) {
//         next(error);
//     }
// });

// json web token
// userSchema.methods.generateToken = 

const User = mongoose.model('USER', userSchema);

module.exports = User;