const mongoose = require('mongoose');



const priceSchema = new mongoose.Schema({
    countryName: {
        type: String,
        required: true
    },
    HFO: {
        type: Number,
        required: true
    },
    HFO_old: {
        type: Number,
        required: true
    },
    VLSFO: {
        type: Number,
        required: true
    },
    VLSFO_old: {
        type: Number,
        required: true
    },
    MGO: {
        type: Number,
        required: true
    },
    MGO_old2: {
        type: Number,
        required: true
    },
    MGO_old3: {
        type: Number,
        required: true
    },
    MGO_old4: {
        type: Number,
        required: true
    },
    date: {
        type: String,
    }
}, { collection: 'graphprices' })

priceSchema.pre('save', function (next) {
    // only for month
    // const currentDate = new Date();
    // const monthName = currentDate.toLocaleString('default', { month: 'long' });
    
    // this.month = monthName;
    // this.date = currentDate.getDate();
    // next();

    // for day and month
    const currentDate = new Date();
    const dayOfMonth = currentDate.getDate();
    const monthName = currentDate.toLocaleString('default', { month: 'short' });

    // Format the date as "DD MMM"
    this.date = `${dayOfMonth} ${monthName}`;

    next();
  });

const Graphprice = mongoose.model('GRAPHPRICE', priceSchema);

module.exports = Graphprice;