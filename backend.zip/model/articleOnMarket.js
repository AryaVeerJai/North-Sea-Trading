const mongoose = require('mongoose');



const articleSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    image: String,
    url: String,
    // image: {
    //     path: String, 
    //     contentType: String 
    // },
    // url: {
    //     path: String, 
    //     contentType: String
    // },
    date: {
        type: String,
    }
}, { collection: 'articles' })

articleSchema.pre('save', function (next) {
    // only for month
    // const currentDate = new Date();
    // const monthName = currentDate.toLocaleString('default', { month: 'long' });
    
    // this.month = monthName;
    // this.date = currentDate.getDate();
    // next();

    // for day and month
    const currentDate = new Date();
    const dayOfMonth = currentDate.getDate();
    const monthName = currentDate.toLocaleString('default', { month: 'short' });
    const yearOfDate = currentDate.getFullYear();

    // Format the date as "DD MMM"
    this.date = `${dayOfMonth} ${monthName} ${yearOfDate}`;

    next();
  });

const MarketPageArticle = mongoose.model('ARTICLE', articleSchema);

module.exports = MarketPageArticle;