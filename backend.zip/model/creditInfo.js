const mongoose = require('mongoose');



const creditSchema = new mongoose.Schema({
    typeofcompany: {
        type: String,
        required: true
    },
    creditperiod: {
        type: String,
        required: true
    },
    companyname: {
        type: String,
        required: true
    },
    companyaddress: {
        type: String,
        required: true
    },
    position: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phoneno: {
        type: Number,
        required: true
    }
}, { collection: 'credits' })

const Credit = mongoose.model('CREDIT', creditSchema);

module.exports = Credit;