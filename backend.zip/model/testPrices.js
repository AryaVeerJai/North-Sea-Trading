const mongoose = require('mongoose');

const fuelPriceSchema = new mongoose.Schema({
  srlno: {
    type: Number,
    required: true,
  },
  countryName: {
    type: String,
    required: true,
  },
  prices: [
    {
      day: {
        type: String,
        required: true,
      },
      HFO: {
        type: Number,
        required: true,
      },
      VLSFO: {
        type: Number,
        required: true,
      },
      MGO: {
        type: Number,
        required: true,
      },
    },
  ],
});

// Custom method to retrieve prices for the last 4 days
fuelPriceSchema.methods.getLast4DaysPrices = function () {
  // Sort prices based on the 'day' property in descending order
  this.prices.sort((a, b) => (a.day > b.day ? -1 : 1));

  // Keep only the last 4 days' data
  return this.prices.slice(0, 4);
};

const FuelPrice = mongoose.model('FuelPrice', fuelPriceSchema);

module.exports = FuelPrice;
