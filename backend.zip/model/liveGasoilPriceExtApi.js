const mongoose = require('mongoose');



const extdataSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    Z23: {
        type: Number,
        required: true
    },
    oldetprice: {
        type: Number
    }
}, { collection: 'livegasoilpricextdatas' })

const LiveGasoilPriceExtData = mongoose.model('LIVEGASOILPRICEXTDATA', extdataSchema);

module.exports = LiveGasoilPriceExtData;