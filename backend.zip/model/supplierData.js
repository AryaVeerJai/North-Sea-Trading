const mongoose = require('mongoose');



const creditSchema = new mongoose.Schema({
    swaps: {
        type: String,
        required: true
    },
    supplytype: {
        type: String,
        required: true
    },
    companyfullname: {
        type: String,
        required: true
    },
    companyaddress: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: Number,
        required: true
    },
    supplyport: {
        type: String,
        required: true
    },
    country: {
        type: String,
        required: true
    },
    additionalcomments: {
        type: String,
        required: true
    }
}, { collection: 'suppliers' })

const Supplier = mongoose.model('SUPPLIER', creditSchema);

module.exports = Supplier;