const mongoose = require('mongoose');



const priceSchema = new mongoose.Schema({
    countryName: {
        type: String,
        required: true
    },
    HFO: {
        type: Number,
        required: true
    },
    HFO_old: {
        type: Number,
        required: true
    },
    VLSFO: {
        type: Number,
        required: true
    },
    VLSFO_old: {
        type: Number,
        required: true
    },
    MGO: {
        type: Number,
        required: true
    },
    MGO_old: {
        type: Number,
        required: true
    }
}, { collection: 'prices' })

const Price = mongoose.model('PRICE', priceSchema);

module.exports = Price;