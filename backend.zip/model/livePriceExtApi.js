const mongoose = require('mongoose');



const extdataSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    Z23: {
        type: Number,
        required: true
    },
    oldetprice: {
        type: Number
    }
}, { collection: 'livepricextdatas' })

const LivePriceExtData = mongoose.model('LIVEPRICEXTDATA', extdataSchema);

module.exports = LivePriceExtData;