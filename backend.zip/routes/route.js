const express = require('express');
const app = express();
const path = require("path")
const axios = require("axios");
const authenticate = require("../middleware/authenticate")
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');
const nodemailer = require('nodemailer');



app.use(cors());
app.use(bodyParser.json());

// const storage = multer.memoryStorage(); // Use memory storage for simplicity, you can configure it based on your needs
// const upload = multer({ dest: 'uploads/' })
// const uploadDestination = path.join(__dirname, 'uploads/');
app.use('uploads', express.static(path.join(__dirname, 'uploads')));

// Configure multer to use disk storage
// const storage = multer.diskStorage({
//   destination: uploadDestination,
//   filename: (req, file, cb) => {
//     cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
//   },
// });


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/")
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname)
  },
})

const upload = multer({ storage: storage });

const transporter = nodemailer.createTransport({
  service: 'Gmail', // You can change this to another service if needed
  auth: {
    user: 'it@northseatrading.org', // Your email address
    pass: 'agxcxacoqjykqyly', // Your app-specific password
  },
});


// const storage = multer.memoryStorage();
// const upload = multer({ storage: storage });


// const upload = multer({ storage: storage });

require('../db/connection');



let User = require("../model/users")
let Price = require("../model/bunkerPrice")
let Graphprice = require("../model/graphPrice") 
let Credit = require("../model/creditInfo")
let jwt = require("jsonwebtoken")
let Accesstoken = require("../model/accessToken")
let LivePriceExtData = require("../model/livePriceExtApi");
let LiveGasoilPriceExtData = require("../model/liveGasoilPriceExtApi");
let Supplier = require("../model/supplierData")
let MarketPageArticle = require("../model/articleOnMarket");




// For user registration
app.post("/register", async(req, res)=>{
  // console.log(req.body);
  const {name, company, position, email, phone, password} = req.body;
  if(!name || !company || !position || !email || !phone || !password){
      res.status(422).json({error:"Fill all the details!"})
      console.log("details messing")
  }
  const welcomeEmail = {
    from: 'it@northseatrading.org', // Sender's email address
    to: email, // Newly registered user's email
    subject: 'Welcome to Northsea Trading',
    // text: `Hello ${name},\n\nWelcome to Your App! We're excited to have you on board.`,
    text: "Northsea Trading would like to thank you for your enquiry. \nOne of our brokers will be back with you shortly. \n\nFor anything urgent please feel free to contact us on what's app or email Bunkers@northseatrading.org \n\nBest wishes. \nNorthsea Trading."
  };
  // console.log("44")
  try {

      const preuser = await User.findOne({email:email})
      if(preuser){
          res.status(422).json({error:"This email is Already Exist!"})
      }else{
          const finalUser = new User ({
            name, company, position, email, phone, password 
          });
          // Here Password Hashing

          const storeData = await finalUser.save();
          // console.log(storeData);
          // res.status(201).json({status:201,storeData})
          res.status(201).json({status:201, message: "Register Sucessfull"})
          await transporter.sendMail(welcomeEmail);
          console.log('Welcome email sent successfully!')
      }
  } catch (error) {
      res.status(422).json(error);
      console.log("Catch Block Error");
  }
});


// login

// User Login
app.post("/login", async(req, res)=>{
  // console.log(req.body);
  const {email, password} = req.body;
  if(!email || !password){
      res.status(422).json({error:"Fill all the details!"})
  }

  try {
      const userValid = await User.findOne({email:email});

      if(userValid){
          const isMatch = await bcrypt.compare(password,userValid.password);
          // const avtiveUser = "Active";
          // const isActive = await  (userValid.userStatus === avtiveUser);
          // console.log(isActive)

          if(!isMatch){
              res.status(422).json({status: 422,  error:"Invalid Details!"})
          }
          // if(!isActive){
          //     res.status(426).json({status: 426, error:"Inactive User"})
          // }
          else{

              // token generate
              const token = await userValid.generateAuthtoken();

              // console.log(token);
              console.log("Login Sucessful!");

              // Cookie Generate
              res.cookie("usercookie", token,{
                  expires:new Date(Date.now()+9000000),
                  httpOnly:true
              });

              const result = {
                  userValid,
                  token
              }
              res.status(201).json({status:201, result})


          }
      }else{
        res.status(404).json({status: 404, error:"Email Not Found!"})
      }


  } catch (error) {
      res.status(401).json(error);
      console.log("90: Server Error catch block");
  }
});

// user all
app.get("/validuser", authenticate,async(req, res)=>{
  // console.log("127");
  try {
      const ValidUserOne = await User.findOne({_id:req.userId});
      res.status(201).json(ValidUserOne);
  } catch (error) {
      res.status(401).json({status:401, error});
  }
});
// logout
// User Logout
app.get("/logout", authenticate, async(req, res)=>{
  try {
      req.rootUser.tokens = req.rootUser.tokens.filter((curelem)=>{
          return curelem.token !== req.token
      });

      res.clearCookie("usercookie", {path:"/"});
      req.rootUser.save();

      res.status(201).json({status:201})


  } catch (error) {
      res.status(201).json({status:401, error})
  }
})

// Get all user
app.get("/alluser", async(req, res)=>{
  try {
    const extDataDb = await User.find({});
    res.status(201).json(extDataDb);
} catch (error) {
    res.status(422).json(error);
}
})


        // =================================

// app.post('/login', async (req, res) => { 
//   console.log(req.body)
//   try {
//     const { email, password } = req.body;

//     const user = await User.findOne({ email });

//     if (!user || user.password !== password) {
//       return res.status(401).json({ message: 'Invalid username or password' });
//     }

//     const token = jwt.sign({ userId: user._id, email: user.email }, process.env.SECRET, { expiresIn: '1h' });

//     res.status(200).json({ token, userId: user._id, email: user.email });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Internal server error' });
//   }
// });





// app.post('/register', async(req, res)=>{
//   try {
//     const {name, company, position, email, phone, password} = req.body;
//     console.log(req.body)
//     // hash the password before saving it to the database in a real-world scenario
//     const newUser = new User({name, company, position, email, phone, password});
//     const token = jwt.sign({_id : newUser._id}, process.env.SECRET);
//     res.json({ token });
//     // const token = await newUser.generateAuthToken();
//     // const user = await newUser.save();
//     // res.cookie("jwt", token, {httpOnly: true}).send(user);


//   } catch (error) {
//     console.error(error);
//     res.status(400).send({error: 'Internal Server Error'});
//   }
// });


app.get('/bunkerprice', async (req, res) => {
    try {
        const bprice = await Price.find({});
        res.status(201).json(bprice);
        // console.log(bprice);
        // console.log("Sucess")
    } catch (error) {
        res.status(422).json(error);
    }
});

// new test
// app.post('/update-fuel-prices', async (req, res) => {
//     const updates = req.body.updates;
//     console.log(req.body)
  
//     try {
//       // Update fuel prices in the database
//       for (const update of updates) {
//         await Price.findOneAndUpdate({ countryName: update.countryName }, update);
//       }
  
//       res.json({ success: true, message: 'Fuel prices updated successfully' });
//       console.log('Fuel prices updated successfully');
//     } catch (error) {
//       console.error(error);
//       res.status(500).json({ error: 'Internal server error' });
//     }
//   });
  

// // new test
// app.post('/update-fuel-prices', async (req, res) => {
//   const updates = req.body.updates;

//   try {
//       for (const update of updates) {
//           // Find the existing document to get the old values
//           const existingDocument = await Price.findOne({ countryName: update.countryName });

//           // Update the document with the new values and store the old values
//           await Price.findOneAndUpdate(
//               { countryName: update.countryName },
//               {
//                   MGO_old: existingDocument.MGO,
//                   HFO_old: existingDocument.HFO,
//                   VLSFO_old: existingDocument.VLSFO,
//                   MGO: update.MGO,
//                   HFO: update.HFO,
//                   VLSFO: update.VLSFO,
//               }
//           );
//       }

//       res.json({ success: true, message: 'Fuel prices updated successfully' });
//       console.log('Fuel prices updated successfully');
//   } catch (error) {
//       console.error(error);
//       res.status(500).json({ error: 'Internal server error' });
//   }
// });

// new test
app.post('/update-fuel-prices', async (req, res) => {
  const updates = req.body.updates;

  try {
      for (const update of updates) {
          // Find the existing document to get the old values
          const existingDocument = await Price.findOne({ countryName: update.countryName });

          // Create an object to hold the update data
          const updateData = {};

          // Conditionally set old values only if new values are different
          if (update.MGO !== undefined && update.MGO !== existingDocument.MGO) {
              updateData.MGO_old = existingDocument.MGO;
              updateData.MGO = update.MGO;
          } else {
              updateData.MGO = existingDocument.MGO;
          }

          if (update.HFO !== undefined && update.HFO !== existingDocument.HFO) {
              updateData.HFO_old = existingDocument.HFO;
              updateData.HFO = update.HFO;
          } else {
              updateData.HFO = existingDocument.HFO;
          }

          if (update.VLSFO !== undefined && update.VLSFO !== existingDocument.VLSFO) {
              updateData.VLSFO_old = existingDocument.VLSFO;
              updateData.VLSFO = update.VLSFO;
          } else {
              updateData.VLSFO = existingDocument.VLSFO;
          }

          // Update the document
          await Price.findOneAndUpdate(
              { countryName: update.countryName },
              updateData
          );
      }

      res.json({ success: true, message: 'Fuel prices updated successfully' });
      console.log('Fuel prices updated successfully');
  } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal server error' });
  }
});


  
  //...


// Endpoint to post data to the database
app.post('/credit-form-details', async (req, res) => {
  const {typeofcompany, creditperiod, companyname, companyaddress, position, email, phoneno} = req.body;
  // const data = req.body;
  // console.log(req.body)

    if(!typeofcompany || !creditperiod || !companyname || !companyaddress || !position || !email || !phoneno){
        return res.status(422).json({error: "Plz fill the field properly"});
    }
    
  const welcomeEmail = {
    from: 'it@northseatrading.org', // Sender's email address
    to: email, // Newly registered user's email
    subject: 'Welcome to Northsea Trading',
    // text: `Hello ${name},\n\nWelcome to Your App! We're excited to have you on board.`,
    text: "Northsea Trading would like to thank you for your enquiry. \nOne of our brokers will be back with you shortly. \n\nFor anything urgent please feel free to contact us on what's app or email Bunkers@northseatrading.org \n\nBest wishes. \nNorthsea Trading."
  };

  // Create a new document using the CompanyDetails model
  // const newCompanyDetails = new Credit(data);

  try {
    const creditExist = await Credit.findOne({email:email});

       if(creditExist){
        return res.status(421).json({error: "Email already Exist"});
        }
         // Create a new document using the CompanyDetails model
        const newCreditDetails = new Credit({typeofcompany, creditperiod, companyname, companyaddress, position, email, phoneno});
    // Save the document to the database
    await newCreditDetails.save();
    await transporter.sendMail(welcomeEmail);
    console.log('Credit Form Data saved successfully');
    res.status(201).send('Credit Form Data inserted successfully');
  } catch (err) {
    console.error('Error saving Credit Form Data:', err.message);
    res.status(500).send('Internal Server Error');
  }
});



app.post('/getaccesstoken', async (req, res) => {
  const tokenEndpoint = 'https://folio-api.artis.works/oauth/token';
// console.log(req.body)
  try {
    const response = await axios.post(tokenEndpoint, {
      audience: 'folio-api',
      grant_type: 'client_credentials',
      client_id: 'iNuJKp1LRk3VBzeaDucHgGSZzGvSoQ8q',
      client_secret: 'Zy-Ip_GgAT1japzy-Fpwv80hNo9Y4WUGLugYI3V6ZtqcH_2kCznQrM7aWVGSgrFm',
    }, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    // Handle the response data as needed
    // console.log('Access Token:', response.data.access_token);
    console.log('Access Token Updated!!');
    res.json({ success: true, accessToken: response.data.access_token });
    const newTokenDetails = ({accessToken: response.data.access_token });
    // await newTokenDetails.save();
    await Accesstoken.findOneAndUpdate({ _id: "658565dea89aa758e832556d" }, newTokenDetails)
    // new Accesstoken({res.data.access_token}).save()
  } catch (error) {
    // console.error('Error fetching access token:', error.message);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});
var  tokeGlobal;
app.get('/accesstoken', async (req, res) => {
  try {
      const token = await Accesstoken.findById({_id:"658565dea89aa758e832556d"});
      var tokeGlobal = token.accessToken;
      // console.log("line156", tokeGlobal)
      res.status(201).json(token.accessToken);
      // console.log(bprice);
      // console.log("Sucess")
  } catch (error) {
      res.status(422).json(error);
  }
});


app.post('/getdatafrom', async (req, res) => {
  // const webtoken = req.body.token;
  const url = 'https://folio-api.artis.works/prices/v2/liveprices';
  const jwtToken = req.body.token; // Replace with your actual JWT token

  const uuids = [
            "d71f82b9-21e2-49f0-9974-4a11a9e5b09f", 
            // not needed it will added in the gas oil Section
            "99d27f4d-0a7e-44fe-b9de-9c27d27f08d2", 
            "29d3a405-cb03-45b4-9ebf-f0176b7ba06a", 
            "662e5a2f-f028-4d18-81dc-89be3ba01f3a", 
            "b0738070-229c-4aa7-b5d0-45b4119dd0e0", 
            "e9e305ee-8605-4503-b3e2-8f5763870cd2", 
            "e506264b-1bcd-429f-b018-f50e3f517133", 
            // Not needed
            "9c68de75-aed7-417b-abab-eaf576d0d6fe", 
            "6ccbf93e-d43d-46ab-ba50-c26659add883"
    // ... (include all the other UUIDs)
  ];

  try {
    // const getToken = await axios.get()
    const response = await axios.post(url, uuids, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${jwtToken}`,
      },
    });

    let jsonData = response.data;

    // new test
    if (jsonData && jsonData.payload) {
      const results = Object.keys(jsonData.payload).map((entryKey) => {
        const entry = jsonData.payload[entryKey];
        return {
          name: entry.name,
          // Z23: entry.data?.Z23?.value
          Z23: entry.data?.F24?.value
        };
      })
      // console.log(results);
        for (const result of results) {
          await LivePriceExtData.findOneAndUpdate({ name: result.name }, result);
        }
      }
    
    // // end new test
    // Handle the response data here
    const livePriceData = await LivePriceExtData.find({});
        res.status(201).json(livePriceData);
    // res.json(response.data);
  } catch (error) {
    // console.error('There was a problem with the request:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/extdatafromdb', async (req, res) => {
  try {
      const extDataDb = await LivePriceExtData.find({});
      res.status(201).json(extDataDb);
  } catch (error) {
      res.status(422).json(error);
  }
});

// for gas oil data from external api
app.post('/getgasoildatafrom', async (req, res) => {
  // console.log(req.body)
  // const webtoken = req.body.token;
  const url = 'https://folio-api.artis.works/prices/v2/liveprices';
  const jwtToken = req.body.token; // Replace with your actual JWT token

  const uuids = [
            // for M0 0.1% BGS
            "d71f82b9-21e2-49f0-9974-4a11a9e5b09f",
            "98cd2f27-d616-4fbd-8866-21b7fc561c0f", 
            "0ed143d2-2eb6-4f07-abb4-026a0345747d",

            // for M0 0.5% GC FP
            // "99d27f4d-0a7e-44fe-b9de-9c27d27f08d2"
    // ... (include all the other UUIDs)
  ];

  try {
    // const getToken = await axios.get()
    const response = await axios.post(url, uuids, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${jwtToken}`,
      },
    });


    let jsonData = response.data;

    if (jsonData && jsonData.payload) {
      const results = Object.keys(jsonData.payload).map((entryKey) => {
        const entry = jsonData.payload[entryKey];
        // Extract name and Z23 values
        const { name, data } = entry;
        // const Z23Value = data?.Z23?.value;
        const Z23Value = data?.F24?.value;

        return {
          name,
          Z23: Z23Value,
        };
      });
      // console.log(results)
      for (const result of results) {
        await LiveGasoilPriceExtData.findOneAndUpdate({ name: result.name }, result);
      }
      res.json(results); 
    }

  } catch (error) {
    // console.error('There was a problem with the request:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/extgasoildatafromdb', async (req, res) => {
  try {
      const extDataDb = await LiveGasoilPriceExtData.find({});
      res.status(201).json(extDataDb);
  } catch (error) {
      res.status(422).json(error);
  }
});



app.get('/creditformdatadb', async (req, res) => {
  try {
      const extDataDb = await Credit.find({});
      res.status(201).json(extDataDb);
  } catch (error) {
      res.status(422).json(error);
  }
});


// Endpoint to post data to the database
app.post('/supplier-form-detail', async (req, res) => {
  const {swaps,  supplytype,  companyfullname,  companyaddress, email, phone,  supplyport,  country,  additionalcomments} = req.body;
  // const data = req.body;
  // console.log(req.body)

    if(!swaps || !supplytype || !companyfullname || !companyaddress || !email || !phone || !supplyport || !country || !additionalcomments){
        return res.status(422).json({error: "Plz fill the field properly"});
    }
    const welcomeEmail = {
      from: 'it@northseatrading.org', // Sender's email address
      to: email, // Newly registered user's email
      subject: 'Welcome to Northsea Trading',
      // text: `Hello ${name},\n\nWelcome to Your App! We're excited to have you on board.`,
      text: "Northsea Trading would like to thank you for your enquiry. \nOne of our brokers will be back with you shortly. \n\nFor anything urgent please feel free to contact us on what's app or email Bunkers@northseatrading.org \n\nBest wishes. \nNorthsea Trading."
    };


  try {
    const creditExist = await Supplier.findOne({companyfullname:companyfullname});

       if(creditExist){
        return res.status(421).json({error: "Supplier already Exist"});
        }
         // Create a new document using the CompanyDetails model
        const newSupplierDetails = new Supplier({swaps,  supplytype,  companyfullname,  companyaddress, email, phone,  supplyport,  country,  additionalcomments});
    // Save the document to the database
    await transporter.sendMail(welcomeEmail);
    await newSupplierDetails.save();
    console.log('Supplier Form Data saved successfully');
    res.status(201).send('Supplier Form Data inserted successfully');
  } catch (err) {
    console.error('Error saving Supplier Data:', err.message);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/supplierformdatadb', async (req, res) => {
  try {
      const extDataDb = await Supplier.find({});
      res.status(201).json(extDataDb);
  } catch (error) {
      res.status(422).json(error);
  }
});

// const express = require("express");

const emailController = require("../controllers/emailController");

// const router = express.Router();

app.route("/sendmail").post(emailController.sendEmail);

// module.exports = router;

// for graph mgo data
app.get("/getgraphmgodata", async (req, res)=>{
  try {
    const mgodata = await Graphprice.find({});
    res.status(201).json(mgodata);
  } catch (error) {
    res.status(422).json(error);
  }
})

// Endpoint to post data to the database
app.post('/postgraphdata', async (req, res) => {
  const {countryName, HFO, HFO_old, VLSFO, VLSFO_old, MGO, MGO_old, MGO_old2, MGO_old3, MGO_old4} = req.body;
  // const data = req.body;
  // console.log(req.body)

    if(!countryName || !HFO || !HFO_old || !VLSFO || !VLSFO_old || !MGO || !MGO_old || !MGO_old2 || !MGO_old3 || !MGO_old4){
        return res.status(422).json({error: "Plz fill the field properly"});
    }


  try {
    // const creditExist = await Graphprice.findOne({countryName:countryName});

      //  if(creditExist){
      //   return res.status(421).json({error: "Graph Price fot this Country already Exist"});
      //   }
         // Create a new document using the CompanyDetails model
        const newSupplierDetails = new Graphprice({countryName, HFO, HFO_old, VLSFO, VLSFO_old, MGO, MGO_old, MGO_old2, MGO_old3, MGO_old4});
    // Save the document to the database
    await newSupplierDetails.save();
    console.log('Graph Price saved successfully');
    res.status(201).send('Graph Price inserted successfully');
  } catch (err) {
    console.error('Error saving Supplier Data:', err.message);
    res.status(500).send('Internal Server Error');
  }
});



// Endpoint to Post Article to database For Market Page
// app.post('/postarticledata',upload.single('image'), async (req, res) => {
// app.post('/postarticledata',upload.fields([{ name: 'image', maxCount: 1 }, { name: 'url', maxCount: 1 }]), async (req, res) => {
//   console.log(req.body)

//   try {
//     // const { title, description, url } = req.body;
//     const { title, description } = req.body;

//     // Check if an image file was indeed uploaded
//     if (req.file) {
//       // const imagePath = path.join('/uploads', req.file.filename);
//       // const pdffile = path.join('/uploads', req.file.filename);
//       const image = req.files['image'][0].path;
//       const url = req.files['url'][0].path;

//       const newArticle = new MarketPageArticle({ title, description, image, url, 
//         // title,
//         // description,
//         // image: {
//         //   // data: req.file.buffer,
//         //   path: imagePath.replace(/\\/g, '/'),
//         //   contentType: req.file.mimetype,
//         // },
//         // url:{
//         //   path: pdffile.replace(/\\/g, '/'),
//         //   contentType: req.file.mimetype,
//         // },
//       });

//       await newArticle.save();
//       // res.json(newArticle);
//       res.json({status:201, message: "Success!"});
//     } else {
//       res.status(400).json({status:400, error: 'No image file uploaded' });
//     }
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({status:500, error: 'Internal Server Error' });
//   }
// });

app.post('/postarticledata', upload.fields([{ name: 'image', maxCount: 1 }, { name: 'url', maxCount: 1 }]), async (req, res) => {
  try {
    const { title, description } = req.body;
    const image = req.files['image'] ? req.files['image'][0].path.replace(/\\/g, '/') : null;
    const url = req.files['url'] ? req.files['url'][0].path.replace(/\\/g, '/') : null;

    const newArticle = new MarketPageArticle({ title, description, image, url });
    await newArticle.save();

    res.json({status:201, message: "Success!"});
  } catch (error) {
    console.error(error);
    res.status(500).json({status:500, error: 'Internal Server Error' });
  }
});


app.get('/getarticles', async (req, res) =>{
  // let articles = await MarketPageArticle.find()
  // .sort([['createdAt','descending']])
  try {
    const articles = await MarketPageArticle.find({});
    res.status(201).json(articles);
  } catch (error) {
    // console.log(error)
    res.status(422).json(error);
  }
})


app.get("/getonearticle/:id", async(req, res) => {
  try {
      console.log(req.params)
      const {id} = req.params;

      const articleindividual = await MarketPageArticle.findById({_id:id});
      // console.log(citynameindividual);
      res.status(201).json(articleindividual);

  } catch (error) {
      res.status(422).json(error);
      
  }
})

// app.patch("/updatearticle/:id", async(req, res) => {
//   console.log(req.body)
//   try {
//       const {id} = req.params;
//       const updatedarticledata = await MarketPageArticle.findByIdAndUpdate(id, req.body,{
//           new:true
//       });
//       console.log(updatedarticledata);
//       res.status(201).json(updatedarticledata);
//   } catch (error) {
//       res.status(422).json(error);
//   }
// })


app.put('/updatearticle/:id', upload.fields([{ name: 'image', maxCount: 1 }, { name: 'url', maxCount: 1 }]), async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description } = req.body;
    const image = req.files['image'] ? req.files['image'][0].path.replace(/\\/g, '/') : null;
    const url = req.files['url'] ? req.files['url'][0].path.replace(/\\/g, '/') : null;

    // Check if the article exists
    const existingArticle = await MarketPageArticle.findById(id);

    if (!existingArticle) {
      return res.status(404).json({ error: 'Article not found' });
    }

    // Update article data
    existingArticle.title = title;
    existingArticle.description = description;
    existingArticle.image = image;
    existingArticle.url = url;

    const updatedArticle = await existingArticle.save();

    res.status(200).json(updatedArticle);
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, error: 'Internal Server Error' });
  }
});

app.delete('/deletearticle/:id', async (req, res) => {
  const id = req.params.id;

  try {
    // Find the article by ID
    // const article = await MarketPageArticle.findById(articleId);
    await MarketPageArticle.findByIdAndDelete({_id:id})

    // If the article doesn't exist, return an error
    // if (!article) {
    //   return res.status(404).json({ error: 'Article not found' });
    // }

    // Delete the article
    // await article.remove();

    // Return success message
    res.json({ message: 'Article deleted successfully' });
  } catch (error) {
    // Handle any errors that occurred during the deletion process
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = app;